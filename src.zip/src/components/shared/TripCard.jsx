function formatKES(amount) {
  return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(amount || 0);
}

function formatWhen(iso) {
  return new Date(iso).toLocaleString('en-KE', {
    weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  });
}

const STATUS_BADGE = {
  scheduled: 'badge-teal', ongoing: 'badge-amber', completed: 'badge-green',
  cancelled: 'badge-danger', expired: 'badge-gray',
};

export default function TripCard({ trip, actions }) {
  return (
    <div className="card card-pad">
      <div className="flex-between" style={{ marginBottom: 10, alignItems: 'flex-start' }}>
        <div>
          <strong style={{ fontSize: 15 }}>{trip.origin} → {trip.destination}</strong>
          <p style={{ margin: '3px 0 0', fontSize: 13, color: 'var(--text-muted)' }}>{formatWhen(trip.departure_time)}</p>
        </div>
        <span className={`badge ${STATUS_BADGE[trip.status] || 'badge-gray'}`}>{trip.status}</span>
      </div>

      <div className="grid-3" style={{ gap: 8, marginBottom: actions ? 14 : 0 }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Price/seat</div>
          <div style={{ fontSize: 14, fontWeight: 700 }}>{formatKES(trip.price_per_seat)}</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Seats</div>
          <div style={{ fontSize: 14, fontWeight: 700 }}>{trip.available_seats} / {trip.total_seats} open</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Vehicle</div>
          <div style={{ fontSize: 14, fontWeight: 700 }}>{trip.vehicle_plate || '—'}</div>
        </div>
      </div>

      {actions && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>{actions}</div>}
    </div>
  );
}