import { useState } from 'react';

function todayLocalMin() {
  const d = new Date(Date.now() + 30 * 60000); // at least 30 min from now
  d.setSeconds(0, 0);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

export default function TripForm({ profile, initialValues, onSubmit, submitting, submitLabel = 'Post trip', error }) {
  const [form, setForm] = useState({
    origin: initialValues?.origin || '',
    destination: initialValues?.destination || '',
    pickup_point: initialValues?.pickup_point || '',
    dropoff_point: initialValues?.dropoff_point || '',
    departure_time: initialValues?.departure_time || '',
    price_per_seat: initialValues?.price_per_seat || '',
    total_seats: initialValues?.total_seats || Math.min(profile?.vehicle_seats || 4, profile?.max_seats_per_trip || 4),
    notes: initialValues?.notes || '',
  });

  function set(field) { return e => setForm(f => ({ ...f, [field]: e.target.value })); }

  function handleSubmit(e) {
    e.preventDefault();
    onSubmit(form);
  }

  const maxSeats = profile?.max_seats_per_trip || 2;

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="grid-2" style={{ gap: 14 }}>
        <div className="form-group">
          <label className="form-label">From</label>
          <input className="form-input" value={form.origin} onChange={set('origin')} placeholder="e.g. Nairobi" required />
        </div>
        <div className="form-group">
          <label className="form-label">To</label>
          <input className="form-input" value={form.destination} onChange={set('destination')} placeholder="e.g. Kisumu" required />
        </div>
      </div>

      <div className="grid-2" style={{ gap: 14 }}>
        <div className="form-group">
          <label className="form-label">Pickup point <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(optional)</span></label>
          <input className="form-input" value={form.pickup_point} onChange={set('pickup_point')} placeholder="e.g. Nyayo Stadium" />
        </div>
        <div className="form-group">
          <label className="form-label">Drop-off point <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(optional)</span></label>
          <input className="form-input" value={form.dropoff_point} onChange={set('dropoff_point')} placeholder="e.g. Kondele" />
        </div>
      </div>

      <div className="form-group">
        <label className="form-label">Departure date & time</label>
        <input className="form-input" type="datetime-local" min={todayLocalMin()} value={form.departure_time} onChange={set('departure_time')} required />
      </div>

      <div className="grid-2" style={{ gap: 14 }}>
        <div className="form-group">
          <label className="form-label">Price per seat (KES)</label>
          <input className="form-input" type="number" min="1" step="1" value={form.price_per_seat} onChange={set('price_per_seat')} placeholder="e.g. 800" required />
        </div>
        <div className="form-group">
          <label className="form-label">Seats to offer</label>
          <select className="form-select" value={form.total_seats} onChange={set('total_seats')} required>
            {Array.from({ length: maxSeats }, (_, i) => i + 1).map(n => (
              <option key={n} value={n}>{n} seat{n > 1 ? 's' : ''}</option>
            ))}
          </select>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 4 }}>
            Your trust level allows up to {maxSeats} seats per trip.
          </p>
        </div>
      </div>

      <div className="form-group">
        <label className="form-label">Notes <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(optional)</span></label>
        <textarea className="form-input" rows={3} value={form.notes} onChange={set('notes')} placeholder="e.g. AC available, one stop in Nakuru" />
      </div>

      <div className="alert alert-info" style={{ fontSize: 13 }}>
        🚗 Posting as {profile?.vehicle_make} {profile?.vehicle_model} · {profile?.vehicle_plate}
      </div>

      <button className="btn btn-primary" disabled={submitting}>
        {submitting ? <span className="spinner" /> : submitLabel}
      </button>
    </form>
  );
}