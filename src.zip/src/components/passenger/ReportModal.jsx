import { useState } from 'react';
import { supabase } from '../../lib/supabase';

const CATEGORIES = [
  { value: 'safety', label: 'Safety concern' },
  { value: 'harassment', label: 'Harassment' },
  { value: 'no_show', label: 'Driver no-show' },
  { value: 'payment_dispute', label: 'Payment dispute' },
  { value: 'vehicle_mismatch', label: "Vehicle didn't match listing" },
  { value: 'reckless_driving', label: 'Reckless driving' },
  { value: 'fake_profile', label: 'Suspicious / fake profile' },
  { value: 'other', label: 'Other' },
];

export default function ReportModal({ tripId, bookingId, reportedUserId, onClose, onSuccess }) {
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    if (!category || !description.trim()) { setError('Please select a category and describe what happened.'); return; }
    setSubmitting(true); setError('');
    const { error: err } = await supabase.from('reports').insert({
      reported_user_id: reportedUserId || null,
      trip_id: tripId || null,
      booking_id: bookingId || null,
      category,
      description: description.trim(),
    });
    setSubmitting(false);
    if (err) { setError(err.message); return; }
    onSuccess();
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3 style={{ fontSize: 17 }}>Report an issue</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {error && <div className="alert alert-danger" style={{ marginBottom: 14 }}>{error}</div>}

        <div className="form-group">
          <label className="form-label">What happened?</label>
          <select className="form-select" value={category} onChange={e => setCategory(e.target.value)}>
            <option value="">Select a category</option>
            {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label">Details</label>
          <textarea className="form-input" rows={4} value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe what happened, as specifically as you can." />
        </div>

        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 16 }}>
          Our support team reviews every report. Repeat or serious issues affect a driver's trust level.
        </p>

        <button className="btn btn-primary btn-full" disabled={submitting} onClick={handleSubmit}>
          {submitting ? <span className="spinner" /> : 'Submit report'}
        </button>
      </div>
    </div>
  );
}
