import { useState } from 'react';
import { supabase } from '../../lib/supabase';

export default function RatingModal({ booking, driverId, onClose, onSuccess }) {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit() {
    if (rating === 0) { setError('Please select a star rating.'); return; }
    setSubmitting(true); setError('');
    // validate_rating_participant() trigger confirms this booking is
    // actually completed and this passenger actually took this trip before
    // allowing the insert — client-side checks here are just UX, not the
    // real guard.
    const { error: err } = await supabase.from('ratings').insert({
      booking_id: booking.id,
      trip_id: booking.trip_id,
      rater_id: booking.passenger_id,
      ratee_id: driverId,
      rating_type: 'passenger_to_driver',
      rating,
      comment: comment.trim() || null,
    });
    setSubmitting(false);
    if (err) { setError(err.message); return; }
    onSuccess();
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3 style={{ fontSize: 17 }}>Rate your driver</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {error && <div className="alert alert-danger" style={{ marginBottom: 14 }}>{error}</div>}

        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 18 }}>
          {[1, 2, 3, 4, 5].map(n => (
            <button
              key={n}
              onClick={() => setRating(n)}
              onMouseEnter={() => setHover(n)}
              onMouseLeave={() => setHover(0)}
              style={{ background: 'none', border: 'none', fontSize: 32, cursor: 'pointer', color: n <= (hover || rating) ? '#F59E0B' : 'var(--border)' }}
            >★</button>
          ))}
        </div>

        <div className="form-group">
          <label className="form-label">Comment <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}>(optional)</span></label>
          <textarea className="form-input" rows={3} value={comment} onChange={e => setComment(e.target.value)} placeholder="How was your trip?" />
        </div>

        <button className="btn btn-primary btn-full" disabled={submitting} onClick={handleSubmit}>
          {submitting ? <span className="spinner" /> : 'Submit rating'}
        </button>
      </div>
    </div>
  );
}
