import { useEffect, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { getSupabaseClient } from './lib/supabaseClients';

// Public
import Landing from './pages/Landing';

// Auth
import PassengerLogin    from './pages/auth/PassengerLogin';
import PassengerRegister from './pages/auth/PassengerRegister';
import DriverLogin       from './pages/auth/DriverLogin';
import DriverRegister    from './pages/auth/DriverRegister';
import AdminLogin        from './pages/auth/AdminLogin';

// Passenger
import PassengerDashboard from './pages/passenger/Dashboard';
import SearchTrips        from './pages/passenger/SearchTrips';
import TripDetails        from './pages/passenger/TripDetails';
import MyBookings         from './pages/passenger/MyBookings';
import PassengerProfile   from './pages/passenger/Profile';

// Driver
import DriverDashboard    from './pages/driver/Dashboard';
import CreateTrip         from './pages/driver/CreateTrip';
import ManageTrips        from './pages/driver/ManageTrips';
import DriverBookings     from './pages/driver/Bookings';
import DriverProfile      from './pages/driver/Profile';
import DriverVerification from './pages/driver/Verification';

// Admin
import AdminDashboard   from './pages/admin/Dashboard';
import DriverReview     from './pages/admin/DriverReview';
import TripOversight    from './pages/admin/TripOversight';
import UserManagement   from './pages/admin/UserManagement';
import Reports          from './pages/admin/Reports';
import AuditLog         from './pages/admin/AuditLog';

// Account status (suspended / banned / pending driver approval) — scoped
// to whichever role tripped it
import Suspended      from './pages/status/Suspended';
import Banned         from './pages/status/Banned';
import PendingApproval from './pages/status/PendingApproval';

// ── Route guards ───────────────────────────────────────────────────────
//
// IMPORTANT: role is now checked against the EXISTENCE of a role-scoped
// profile (driverProfile / passengerProfile), never against a single
// global `profile.role`. One identity can have both, so "does this
// identity have a driver profile" is a completely separate question from
// "does this identity have a passenger profile" -- and neither implies
// anything about which dashboard THIS route should show. The `role` prop
// passed to ProtectedRoute is the only thing that decides that.
// `allowUnverifiedDriver`: driver routes that must stay reachable even
// before verification is approved -- currently /driver/verification (so a
// driver can actually submit/resubmit documents) and /driver/profile (so
// they can fix contact details). Every other driver route requires
// verification_status === 'verified', enforced below.
function ProtectedRoute({ children, role, allowUnverifiedDriver = false }) {
  const { user, loading, isAdmin, statusFor, verificationStatus, isDriverVerified } = useAuth();

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner" />
      </div>
    );
  }

  if (!user) return <Navigate to="/" replace />;

  // Admin routes: gated purely on the is_admin flag.
  if (role === 'admin') {
    return isAdmin ? children : <Navigate to="/admin/login" replace />;
  }

  // Driver / passenger routes: gated on that specific role profile
  // existing for this identity -- never on the other role, and never on
  // whichever role happens to be "primary".
  const status = statusFor(role);

  if (!status.exists) {
    // This identity has no profile for the role this route requires.
    // Do NOT fall back to another role's dashboard -- send them to the
    // matching login/register flow instead.
    return <Navigate to={`/${role}/login`} replace />;
  }

  // Ban/suspension always takes priority over verification state -- a
  // banned driver sees Banned, never PendingApproval, even if they were
  // also never verified.
  if (status.isBanned) return <Banned reason={status.suspensionReason} />;
  if (status.isSuspended) return <Suspended reason={status.suspensionReason} />;

  // Driver-only: block everything except the exempted routes until the
  // account is approved. Passengers have no equivalent gate -- they never
  // require admin approval.
  if (role === 'driver' && !isDriverVerified && !allowUnverifiedDriver) {
    return <PendingApproval />;
  }

  return children;
}

// Portal sessions are now isolated (see AuthContext / supabaseClients), so
// on a portal-specific login page (preferredRole set) `useAuth()` already
// reflects that exact portal's session and the check below is direct.
//
// On the generic landing page ("/"), there is no single portal in scope,
// so `useAuth()` reports no user even if the person is separately signed
// in as driver and/or passenger and/or admin elsewhere. We do a light,
// read-only check of all three portals' stored sessions to decide what to
// show -- redirecting automatically only when exactly one is signed in,
// otherwise letting Landing offer explicit "Continue as..." choices.
function useAnyActiveSessions() {
  const [sessions, setSessions] = useState(null); // null = still checking

  useEffect(() => {
    let cancelled = false;
    Promise.all(
      ['admin', 'driver', 'passenger'].map(async (p) => {
        const { data: { session } } = await getSupabaseClient(p).auth.getSession();
        return [p, !!session];
      })
    ).then((pairs) => {
      if (!cancelled) setSessions(Object.fromEntries(pairs));
    });
    return () => { cancelled = true; };
  }, []);

  return sessions;
}

function PublicRoute({ children, preferredRole = null }) {
  const { user, loading, isAdmin, isDriver, isPassenger } = useAuth();
  const anySessions = useAnyActiveSessions();

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner" />
      </div>
    );
  }

  if (user) {
    // On a role-specific login/register page, only redirect away if the
    // person already has THAT role's session active -- e.g. someone
    // signed in as passenger (but not driver) landing on /driver/login
    // should still see the driver login/register form, not get bounced.
    if (preferredRole === 'admin' && isAdmin) return <Navigate to="/admin/dashboard" replace />;
    if (preferredRole === 'driver' && isDriver) return <Navigate to="/driver/dashboard" replace />;
    if (preferredRole === 'passenger' && isPassenger) return <Navigate to="/passenger/dashboard" replace />;
  }

  if (!preferredRole && anySessions) {
    const active = Object.entries(anySessions).filter(([, has]) => has).map(([p]) => p);
    if (active.length === 1) {
      const dest = active[0] === 'admin' ? '/admin/dashboard' : `/${active[0]}/dashboard`;
      return <Navigate to={dest} replace />;
    }
    // 0 or 2+ active sessions: fall through to Landing, which can offer
    // "Continue as driver" / "Continue as passenger" / "Admin" links.
  }

  return children;
}

// ── App ────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={<PublicRoute><Landing /></PublicRoute>} />

      {/* Auth — passenger */}
      <Route path="/passenger/login"    element={<PublicRoute preferredRole="passenger"><PassengerLogin /></PublicRoute>} />
      <Route path="/passenger/register" element={<PublicRoute preferredRole="passenger"><PassengerRegister /></PublicRoute>} />

      {/* Auth — driver */}
      <Route path="/driver/login"    element={<PublicRoute preferredRole="driver"><DriverLogin /></PublicRoute>} />
      <Route path="/driver/register" element={<PublicRoute preferredRole="driver"><DriverRegister /></PublicRoute>} />

      {/* Auth — admin */}
      <Route path="/admin/login" element={<PublicRoute preferredRole="admin"><AdminLogin /></PublicRoute>} />

      {/* Passenger pages */}
      <Route path="/passenger/dashboard" element={<ProtectedRoute role="passenger"><PassengerDashboard /></ProtectedRoute>} />
      <Route path="/passenger/search"    element={<ProtectedRoute role="passenger"><SearchTrips /></ProtectedRoute>} />
      <Route path="/passenger/trips/:tripId" element={<ProtectedRoute role="passenger"><TripDetails /></ProtectedRoute>} />
      <Route path="/passenger/bookings"  element={<ProtectedRoute role="passenger"><MyBookings /></ProtectedRoute>} />
      <Route path="/passenger/profile"   element={<ProtectedRoute role="passenger"><PassengerProfile /></ProtectedRoute>} />

      {/* Driver pages */}
      <Route path="/driver/dashboard"    element={<ProtectedRoute role="driver"><DriverDashboard /></ProtectedRoute>} />
      <Route path="/driver/create-trip"  element={<ProtectedRoute role="driver"><CreateTrip /></ProtectedRoute>} />
      <Route path="/driver/trips"        element={<ProtectedRoute role="driver"><ManageTrips /></ProtectedRoute>} />
      <Route path="/driver/bookings"     element={<ProtectedRoute role="driver"><DriverBookings /></ProtectedRoute>} />
      <Route path="/driver/profile"      element={<ProtectedRoute role="driver" allowUnverifiedDriver><DriverProfile /></ProtectedRoute>} />
      <Route path="/driver/verification" element={<ProtectedRoute role="driver" allowUnverifiedDriver><DriverVerification /></ProtectedRoute>} />

      {/* Admin pages */}
      <Route path="/admin/dashboard"      element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/drivers/review" element={<ProtectedRoute role="admin"><DriverReview /></ProtectedRoute>} />
      <Route path="/admin/trips"          element={<ProtectedRoute role="admin"><TripOversight /></ProtectedRoute>} />
      <Route path="/admin/users"          element={<ProtectedRoute role="admin"><UserManagement /></ProtectedRoute>} />
      <Route path="/admin/reports"        element={<ProtectedRoute role="admin"><Reports /></ProtectedRoute>} />
      <Route path="/admin/audit-log"      element={<ProtectedRoute role="admin"><AuditLog /></ProtectedRoute>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
