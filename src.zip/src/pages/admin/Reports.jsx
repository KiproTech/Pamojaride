import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';

const STATUS_TABS = [
  { value: 'open', label: 'Open' },
  { value: 'under_review', label: 'Under Review' },
  { value: 'resolved', label: 'Resolved' },
  { value: 'dismissed', label: 'Dismissed' },
  { value: 'all', label: 'All' },
];

const CATEGORY_LABELS = {
  safety: 'Safety', harassment: 'Harassment', no_show: 'No-show',
  payment_dispute: 'Payment dispute', fake_profile: 'Fake profile',
  vehicle_mismatch: 'Vehicle mismatch', reckless_driving: 'Reckless driving', other: 'Other',
};

const STATUS_BADGE = { open: 'badge-amber', under_review: 'badge-teal', resolved: 'badge-green', dismissed: 'badge-gray' };

function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString('en-KE', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

// Ban/suspension appeals (submitted from the Banned/Suspended pages) land
// here too — they're stored in this same `reports` table with
// category: 'other' and a "[Account appeal ...]" prefix on the
// description, rather than a separate table, since this table already
// covers exactly the reporter/description/status/resolution shape needed.
export default function Reports() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [statusFilter, setStatusFilter] = useState('open');
  const [expandedId, setExpandedId] = useState(null);
  const [noteDraft, setNoteDraft] = useState('');
  const [busyId, setBusyId] = useState(null);

  async function load(activeFilter) {
    setLoading(true);
    setError('');
    let query = supabase
      .from('reports')
      .select('*, reporter:reporter_id(full_name, email), reported:reported_user_id(full_name, email)')
      .order('created_at', { ascending: false });
    if (activeFilter !== 'all') query = query.eq('status', activeFilter);

    const { data, error: fetchError } = await query;
    if (fetchError) setError(fetchError.message);
    else setReports(data || []);
    setLoading(false);
  }

  useEffect(() => { load(statusFilter); }, [statusFilter]);

  function toggleExpand(report) {
    if (expandedId === report.id) { setExpandedId(null); return; }
    setExpandedId(report.id);
    setNoteDraft(report.resolution_notes || '');
  }

  async function updateStatus(report, newStatus) {
    setBusyId(report.id);
    setError('');
    const adminId = (await supabase.auth.getUser()).data.user?.id;
    const { error: updateError } = await supabase
      .from('reports')
      .update({
        status: newStatus,
        resolution_notes: noteDraft.trim() || report.resolution_notes,
        resolved_by: newStatus === 'resolved' || newStatus === 'dismissed' ? adminId : report.resolved_by,
        resolved_at: newStatus === 'resolved' || newStatus === 'dismissed' ? new Date().toISOString() : report.resolved_at,
      })
      .eq('id', report.id);
    setBusyId(null);
    if (updateError) { setError(updateError.message); return; }
    setReports(rs => rs.map(r => r.id === report.id ? { ...r, status: newStatus, resolution_notes: noteDraft.trim() || r.resolution_notes } : r));
    if (statusFilter !== 'all' && newStatus !== statusFilter) {
      setReports(rs => rs.filter(r => r.id !== report.id));
    }
    setExpandedId(null);
  }

  const isAppeal = (r) => r.description?.startsWith('[Account appeal');

  return (
    <DashboardLayout title="Reports & Appeals">
      <div className="page-header">
        <h1>Reports & Appeals</h1>
        <p>Passenger/driver complaints and account-ban appeals, in one queue.</p>
      </div>

      {error && <div className="alert alert-danger" style={{ marginBottom: 20 }}>{error}</div>}

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {STATUS_TABS.map(t => (
          <button
            key={t.value}
            className={`btn btn-sm ${statusFilter === t.value ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setStatusFilter(t.value)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="skeleton-row" /><div className="skeleton-row" />
        </div>
      ) : reports.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎉</div>
          <h3>Nothing here</h3>
          <p>No reports match this filter.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {reports.map(r => (
            <div key={r.id} className="card card-pad">
              <div className="flex-between" style={{ marginBottom: 8, flexWrap: 'wrap', gap: 8 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span className={`badge ${STATUS_BADGE[r.status] || 'badge-gray'}`}>{r.status.replace('_', ' ')}</span>
                  <span className="badge badge-gray">{isAppeal(r) ? 'Account appeal' : CATEGORY_LABELS[r.category] || r.category}</span>
                </div>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatDate(r.created_at)}</span>
              </div>

              <div style={{ fontSize: 13.5, marginBottom: 6 }}>
                <strong>{r.reporter?.full_name || 'Unknown user'}</strong>
                <span style={{ color: 'var(--text-muted)' }}> ({r.reporter?.email})</span>
                {r.reported && (
                  <> → reported <strong>{r.reported.full_name}</strong></>
                )}
              </div>

              <p style={{ fontSize: 13.5, color: 'var(--text-secondary, #334155)', whiteSpace: 'pre-wrap', margin: '8px 0 12px' }}>
                {r.description}
              </p>

              {expandedId === r.id ? (
                <div style={{ borderTop: '1px solid var(--border)', paddingTop: 12 }}>
                  <div className="form-group" style={{ marginBottom: 10 }}>
                    <label className="form-label">Resolution notes (internal)</label>
                    <textarea
                      className="form-input"
                      rows={2}
                      style={{ resize: 'vertical' }}
                      value={noteDraft}
                      onChange={e => setNoteDraft(e.target.value)}
                      placeholder="e.g. Reviewed ban decision, contacted driver, upheld original ban."
                    />
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button className="btn btn-sm btn-outline" disabled={busyId === r.id} onClick={() => updateStatus(r, 'under_review')}>Mark under review</button>
                    <button className="btn btn-sm btn-primary" disabled={busyId === r.id} onClick={() => updateStatus(r, 'resolved')}>Resolve</button>
                    <button className="btn btn-sm btn-ghost" disabled={busyId === r.id} onClick={() => updateStatus(r, 'dismissed')}>Dismiss</button>
                    <button className="btn btn-sm btn-ghost" disabled={busyId === r.id} onClick={() => setExpandedId(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <button className="btn btn-sm btn-outline" onClick={() => toggleExpand(r)}>
                  {r.resolution_notes ? 'View / update notes' : 'Review'}
                </button>
              )}

              {r.resolution_notes && expandedId !== r.id && (
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 8, borderTop: '1px solid var(--border)', paddingTop: 8 }}>
                  <strong>Notes:</strong> {r.resolution_notes}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
