import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import BookingCard from '../../components/shared/BookingCard';
import RatingModal from '../../components/passenger/RatingModal';
import ReportModal from '../../components/passenger/ReportModal';

const TABS = [
  { key: 'upcoming', label: 'Upcoming', statuses: ['pending', 'confirmed'] },
  { key: 'completed', label: 'Completed', statuses: ['completed'] },
  { key: 'cancelled', label: 'Cancelled / No-show', statuses: ['cancelled', 'no_show'] },
];

export default function MyBookings() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [ratedBookingIds, setRatedBookingIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('upcoming');
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState('');
  const [rateTarget, setRateTarget] = useState(null);
  const [reportTarget, setReportTarget] = useState(null);
  const [contactInfo, setContactInfo] = useState(null);

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase
      .from('bookings')
      .select('*, trips(id, origin, destination, departure_time, driver_id, status)')
      .eq('passenger_id', user.id)
      .order('created_at', { ascending: false });
    if (!err) setBookings(data || []);

    const { data: myRatings } = await supabase
      .from('ratings').select('booking_id').eq('rater_id', user.id).eq('rating_type', 'passenger_to_driver');
    setRatedBookingIds(new Set((myRatings || []).map(r => r.booking_id)));

    setLoading(false);
  }

  useEffect(() => { if (user) load(); }, [user]);

  async function handleCancel(bookingId) {
    if (!confirm('Cancel this booking?')) return;
    setBusyId(bookingId); setError('');
    const { error: err } = await supabase.rpc('cancel_booking', { p_booking_id: bookingId, p_reason: 'Cancelled by passenger' });
    setBusyId(null);
    if (err) setError(err.message); else load();
  }

  async function handleContact(tripId) {
    setBusyId(tripId); setError('');
    const { data, error: err } = await supabase.rpc('get_trip_contact', { p_trip_id: tripId });
    setBusyId(null);
    if (err) { setError(err.message); return; }
    setContactInfo(data?.[0] || null);
  }

  const activeTab = TABS.find(t => t.key === tab);
  const filtered = bookings.filter(b => activeTab.statuses.includes(b.status));

  return (
    <DashboardLayout title="My Bookings">
      <div className="page-header">
        <h1>My Bookings</h1>
        <p>Track your upcoming, completed, and cancelled trips.</p>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`btn btn-sm ${tab === t.key ? 'btn-primary' : 'btn-outline'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger" style={{ marginBottom: 16 }}>{error}</div>}

      {contactInfo && (
        <div className="alert alert-info" style={{ marginBottom: 16 }}>
          📞 <strong>{contactInfo.full_name}</strong>: <a href={`tel:${contactInfo.phone}`}>{contactInfo.phone}</a>
          <button className="btn btn-sm btn-ghost" style={{ marginLeft: 12 }} onClick={() => setContactInfo(null)}>Dismiss</button>
        </div>
      )}

      {loading ? (
        <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎫</div>
          <h3>No {activeTab.label.toLowerCase()} bookings</h3>
          <p>{tab === 'upcoming' ? 'Search for a trip to get started.' : 'Nothing here yet.'}</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {filtered.map(b => {
            const alreadyRated = ratedBookingIds.has(b.id);
            return (
              <BookingCard
                key={b.id}
                booking={b}
                personName={`${b.trips?.origin} → ${b.trips?.destination}`}
                personLabel={new Date(b.trips?.departure_time).toLocaleString('en-KE', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                actions={
                  <>
                    {['pending', 'confirmed'].includes(b.status) && (
                      <>
                        <button className="btn btn-sm btn-outline" disabled={busyId === b.trips?.id} onClick={() => handleContact(b.trips.id)}>
                          {busyId === b.trips?.id ? <span className="spinner" /> : '📞 Contact driver'}
                        </button>
                        <button className="btn btn-sm btn-danger" disabled={busyId === b.id} onClick={() => handleCancel(b.id)}>
                          {busyId === b.id ? <span className="spinner" /> : 'Cancel'}
                        </button>
                      </>
                    )}
                    {b.status === 'completed' && !alreadyRated && (
                      <button className="btn btn-sm btn-primary" onClick={() => setRateTarget(b)}>⭐ Rate driver</button>
                    )}
                    {b.status === 'completed' && alreadyRated && (
                      <span className="badge badge-gray">Rated</span>
                    )}
                    <button className="btn btn-sm btn-ghost" onClick={() => setReportTarget(b)}>🚩 Report</button>
                  </>
                }
              />
            );
          })}
        </div>
      )}

      {rateTarget && (
        <RatingModal
          booking={rateTarget}
          driverId={rateTarget.trips.driver_id}
          onClose={() => setRateTarget(null)}
          onSuccess={() => { setRateTarget(null); load(); }}
        />
      )}

      {reportTarget && (
        <ReportModal
          tripId={reportTarget.trips?.id}
          bookingId={reportTarget.id}
          reportedUserId={reportTarget.trips?.driver_id}
          onClose={() => setReportTarget(null)}
          onSuccess={() => { setReportTarget(null); alert('Report submitted. Our team will review it shortly.'); }}
        />
      )}
    </DashboardLayout>
  );
}
