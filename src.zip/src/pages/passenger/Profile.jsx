import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';

export default function Profile() {
  const { profile, updateProfile } = useAuth();

  return (
    <DashboardLayout title="Profile">
      <div className="page-header">
        <h1>Your Profile</h1>
        <p>Manage your personal details and account security.</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 560 }}>
        <PersonalInfoCard profile={profile} updateProfile={updateProfile} />
        <PasswordCard />
      </div>
    </DashboardLayout>
  );
}

function PersonalInfoCard({ profile, updateProfile }) {
  const [form, setForm] = useState({ full_name: profile?.full_name || '', phone: profile?.phone || '' });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  function set(field) { return e => setForm(f => ({ ...f, [field]: e.target.value })); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true); setMessage(null);
    const { error } = await updateProfile({ full_name: form.full_name, phone: form.phone });
    setMessage(error ? { type: 'danger', text: error.message } : { type: 'success', text: 'Saved.' });
    setSaving(false);
  }

  return (
    <div className="card card-pad">
      <h3 style={{ fontSize: 16, marginBottom: 16 }}>Personal Information</h3>
      {message && <div className={`alert alert-${message.type}`} style={{ marginBottom: 14 }}>{message.text}</div>}
      <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="form-group">
          <label className="form-label">Full Name</label>
          <input className="form-input" value={form.full_name} onChange={set('full_name')} />
        </div>
        <div className="form-group">
          <label className="form-label">Phone Number</label>
          <input className="form-input" type="tel" value={form.phone} onChange={set('phone')} />
        </div>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input className="form-input" value={profile?.email || ''} disabled style={{ opacity: 0.6, cursor: 'not-allowed' }} />
        </div>
        <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-start' }} disabled={saving}>
          {saving ? <span className="spinner" /> : 'Save changes'}
        </button>
      </form>
    </div>
  );
}

function PasswordCard() {
  const [form, setForm] = useState({ newPassword: '', confirm: '' });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);

  function set(field) { return e => setForm(f => ({ ...f, [field]: e.target.value })); }

  async function handleSubmit(e) {
    e.preventDefault();
    setMessage(null);
    if (form.newPassword.length < 8) { setMessage({ type: 'danger', text: 'Password must be at least 8 characters.' }); return; }
    if (form.newPassword !== form.confirm) { setMessage({ type: 'danger', text: 'Passwords do not match.' }); return; }

    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: form.newPassword });
    setSaving(false);
    if (error) setMessage({ type: 'danger', text: error.message });
    else { setMessage({ type: 'success', text: 'Password updated.' }); setForm({ newPassword: '', confirm: '' }); }
  }

  return (
    <div className="card card-pad">
      <h3 style={{ fontSize: 16, marginBottom: 16 }}>Change Password</h3>
      {message && <div className={`alert alert-${message.type}`} style={{ marginBottom: 14 }}>{message.text}</div>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="form-group">
          <label className="form-label">New Password</label>
          <input className="form-input" type="password" value={form.newPassword} onChange={set('newPassword')} placeholder="At least 8 characters" />
        </div>
        <div className="form-group">
          <label className="form-label">Confirm New Password</label>
          <input className="form-input" type="password" value={form.confirm} onChange={set('confirm')} />
        </div>
        <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-start' }} disabled={saving}>
          {saving ? <span className="spinner" /> : 'Update password'}
        </button>
      </form>
    </div>
  );
}
