import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import BookingModal from '../../components/passenger/BookingModal';

function formatKES(amount) {
  return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(amount || 0);
}

export default function TripDetails() {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [trip, setTrip] = useState(null);
  const [driver, setDriver] = useState(null);
  const [rating, setRating] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showBooking, setShowBooking] = useState(false);
  const [justBooked, setJustBooked] = useState(false);

  useEffect(() => {
    let active = true;
    async function load() {
      setLoading(true);
      const { data: tripData, error: tripErr } = await supabase.from('trips').select('*').eq('id', tripId).single();
      if (!active) return;
      if (tripErr) { setError('This trip could not be found.'); setLoading(false); return; }
      setTrip(tripData);

      // Safe public view — never exposes phone/KYC/emergency contact etc.
      const { data: driverData } = await supabase.from('driver_public_profile').select('*').eq('id', tripData.driver_id).single();
      if (active) setDriver(driverData);

      const { data: ratings } = await supabase.from('ratings').select('rating').eq('ratee_id', tripData.driver_id).eq('rating_type', 'passenger_to_driver');
      if (active && ratings?.length) {
        setRating((ratings.reduce((s, r) => s + r.rating, 0) / ratings.length).toFixed(1));
      }
      setLoading(false);
    }
    load();
    return () => { active = false; };
  }, [tripId]);

  if (loading) {
    return <DashboardLayout title="Trip Details"><div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" /></div></DashboardLayout>;
  }
  if (error || !trip) {
    return <DashboardLayout title="Trip Details"><div className="alert alert-danger">{error}</div></DashboardLayout>;
  }

  return (
    <DashboardLayout title="Trip Details">
      <button className="btn btn-sm btn-ghost" onClick={() => navigate(-1)} style={{ marginBottom: 16 }}>← Back</button>

      {justBooked && (
        <div className="alert alert-success" style={{ marginBottom: 20 }}>
          🎉 Booking confirmed! Find it under <strong>My Bookings</strong>.
        </div>
      )}

      <div className="card card-pad" style={{ marginBottom: 20 }}>
        <div className="flex-between" style={{ alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <h1 style={{ fontSize: 22, marginBottom: 4 }}>{trip.origin} → {trip.destination}</h1>
            <p style={{ color: 'var(--text-muted)' }}>
              {new Date(trip.departure_time).toLocaleString('en-KE', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          <span className="badge badge-teal">{trip.status}</span>
        </div>

        <div className="grid-3" style={{ gap: 16, marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Price per seat</div>
            <div style={{ fontSize: 18, fontWeight: 800 }}>{formatKES(trip.price_per_seat)}</div>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Seats available</div>
            <div style={{ fontSize: 18, fontWeight: 800 }}>{trip.available_seats} / {trip.total_seats}</div>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase' }}>Vehicle</div>
            <div style={{ fontSize: 15, fontWeight: 700 }}>{trip.vehicle_make} {trip.vehicle_model}</div>
          </div>
        </div>

        {(trip.pickup_point || trip.dropoff_point) && (
          <div style={{ fontSize: 13.5, color: 'var(--text)', marginBottom: 12 }}>
            {trip.pickup_point && <div>📍 Pickup: {trip.pickup_point}</div>}
            {trip.dropoff_point && <div>🏁 Drop-off: {trip.dropoff_point}</div>}
          </div>
        )}

        {trip.notes && <p style={{ fontSize: 13.5, color: 'var(--text-muted)', marginBottom: 16 }}>{trip.notes}</p>}

        {trip.status === 'scheduled' && trip.available_seats > 0 ? (
          <button className="btn btn-primary" onClick={() => setShowBooking(true)}>Book this trip</button>
        ) : (
          <div className="alert alert-amber">This trip is no longer available for booking.</div>
        )}
      </div>

      <div className="card card-pad">
        <h3 style={{ fontSize: 15, marginBottom: 12 }}>Your driver</h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span className="topbar-avatar" style={{ width: 44, height: 44, fontSize: 15 }}>
            {(driver?.full_name || '?').split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase()}
          </span>
          <div>
            <strong style={{ fontSize: 14.5 }}>{driver?.full_name || 'Driver'}</strong>
            <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
              {rating ? `⭐ ${rating} rating` : 'No ratings yet'} · Trust Level {driver?.trust_level || 1} · {driver?.trips_completed || 0} trips completed
            </div>
          </div>
        </div>
      </div>

      {showBooking && (
        <BookingModal
          trip={trip}
          onClose={() => setShowBooking(false)}
          onSuccess={() => { setShowBooking(false); setJustBooked(true); }}
        />
      )}
    </DashboardLayout>
  );
}
