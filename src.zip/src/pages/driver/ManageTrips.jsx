import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import TripCard from '../../components/shared/TripCard';

const FILTERS = [
  { key: 'upcoming', label: 'Upcoming', statuses: ['scheduled', 'ongoing'] },
  { key: 'past', label: 'Past', statuses: ['completed', 'expired'] },
  { key: 'cancelled', label: 'Cancelled', statuses: ['cancelled'] },
];

export default function ManageTrips() {
  const { user, isDriverVerified } = useAuth();
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('upcoming');
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true);
    const { data, error: err } = await supabase
      .from('trips')
      .select('*')
      .eq('driver_id', user.id)
      .order('departure_time', { ascending: false });
    if (!err) setTrips(data || []);
    setLoading(false);
  }

  useEffect(() => { if (user) load(); }, [user]);

  async function handleCancel(tripId) {
    if (!confirm('Cancel this trip? All passengers with active bookings will be notified.')) return;
    setBusyId(tripId); setError('');
    const { error: err } = await supabase.rpc('cancel_trip', { p_trip_id: tripId, p_reason: 'Cancelled by driver' });
    setBusyId(null);
    if (err) setError(err.message); else load();
  }

  async function handleComplete(tripId) {
    if (!confirm('Mark this trip as completed? This finalizes all confirmed bookings.')) return;
    setBusyId(tripId); setError('');
    const { error: err } = await supabase.rpc('complete_trip', { p_trip_id: tripId });
    setBusyId(null);
    if (err) setError(err.message); else load();
  }

  const activeFilter = FILTERS.find(f => f.key === filter);
  const filtered = trips.filter(t => activeFilter.statuses.includes(t.status));

  return (
    <DashboardLayout title="My Trips">
      <div className="page-header flex-between" style={{ flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1>My Trips</h1>
          <p>Manage the trips you've posted.</p>
        </div>
        {isDriverVerified && <Link to="/driver/create-trip" className="btn btn-primary btn-sm">+ Post a trip</Link>}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`btn btn-sm ${filter === f.key ? 'btn-primary' : 'btn-outline'}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger" style={{ marginBottom: 16 }}>{error}</div>}

      {loading ? (
        <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🗺️</div>
          <h3>No {activeFilter.label.toLowerCase()} trips</h3>
          <p>{filter === 'upcoming' ? "Post a trip to start earning." : "Nothing here yet."}</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {filtered.map(trip => (
            <TripCard
              key={trip.id}
              trip={trip}
              actions={
                <>
                  <Link to={`/driver/bookings?trip=${trip.id}`} className="btn btn-sm btn-outline">View bookings</Link>
                  {trip.status === 'scheduled' && (
                    <>
                      {new Date(trip.departure_time) <= new Date() && (
                        <button className="btn btn-sm btn-primary" disabled={busyId === trip.id} onClick={() => handleComplete(trip.id)}>
                          {busyId === trip.id ? <span className="spinner" /> : 'Mark completed'}
                        </button>
                      )}
                      <button className="btn btn-sm btn-danger" disabled={busyId === trip.id} onClick={() => handleCancel(trip.id)}>
                        {busyId === trip.id ? <span className="spinner" /> : 'Cancel trip'}
                      </button>
                    </>
                  )}
                </>
              }
            />
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}