import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import TripForm from '../../components/driver/TripForm';

export default function CreateTrip() {
  const { user, driverProfile, isDriverVerified } = useAuth();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(form) {
    setError('');
    if (new Date(form.departure_time) <= new Date()) {
      setError('Departure time must be in the future.');
      return;
    }
    setSubmitting(true);

    const totalSeats = parseInt(form.total_seats, 10);
    const { error: insertError } = await supabase.from('trips').insert({
      driver_id: user.id,
      origin: form.origin.trim(),
      destination: form.destination.trim(),
      pickup_point: form.pickup_point.trim() || null,
      dropoff_point: form.dropoff_point.trim() || null,
      departure_time: new Date(form.departure_time).toISOString(),
      price_per_seat: parseFloat(form.price_per_seat),
      total_seats: totalSeats,
      available_seats: totalSeats,
      // Vehicle snapshot, per design: a trip's advertised vehicle doesn't
      // change if the driver edits their profile's vehicle later.
      vehicle_make: driverProfile?.vehicle_make,
      vehicle_model: driverProfile?.vehicle_model,
      vehicle_plate: driverProfile?.vehicle_plate,
      vehicle_color: driverProfile?.vehicle_color,
      notes: form.notes.trim() || null,
    });

    setSubmitting(false);
    if (insertError) { setError(insertError.message); return; }
    navigate('/driver/trips');
  }

  if (!isDriverVerified) {
    return (
      <DashboardLayout title="Post a Trip">
        <div className="alert alert-amber">
          🔒 You need to complete driver verification before you can post a trip.
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Post a Trip">
      <div className="page-header">
        <h1>Post a Trip</h1>
        <p>Fill your empty seats and start earning.</p>
      </div>
      <div className="card card-pad" style={{ maxWidth: 640 }}>
        <TripForm profile={driverProfile} onSubmit={handleSubmit} submitting={submitting} error={error} />
      </div>
    </DashboardLayout>
  );
}