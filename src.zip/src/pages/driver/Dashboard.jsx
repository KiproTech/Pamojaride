import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import VerificationPopup from '../../components/driver/Verificationpopup';

function formatKES(amount) {
  return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(amount || 0);
}

const QUICK_ACTIONS = [
  { to: '/driver/create-trip', icon: '🚌', title: 'Post a trip', sub: 'Fill your empty seats', requiresVerified: true },
  { to: '/driver/trips', icon: '🗺️', title: 'Manage trips', sub: 'View and edit your posted trips' },
  { to: '/driver/bookings', icon: '🎫', title: 'Bookings', sub: "See who's booked your seats" },
  { to: '/driver/profile', icon: '👤', title: 'Profile', sub: 'Update your details' },
];

export default function Dashboard() {
  const { user, profile, driverProfile, verificationStatus, isDriverVerified } = useAuth();
  const [stats, setStats] = useState({ activeTrips: 0, weeklyBookings: 0, earnings: 0, rating: null });
  const [recentBookings, setRecentBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user) return;
    let active = true;

    async function load() {
      setError('');
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

      try {
        const [tripsRes, bookingsRes, ratingsRes, recentRes] = await Promise.all([
          supabase.from('trips').select('id', { count: 'exact', head: true })
            .eq('driver_id', user.id).in('status', ['scheduled', 'ongoing']),
          supabase.from('bookings').select('total_price, created_at, status, trip_id, trips!inner(driver_id)')
            .eq('trips.driver_id', user.id).gte('created_at', weekAgo),
          supabase.from('ratings').select('rating').eq('ratee_id', user.id).eq('rating_type', 'passenger_to_driver'),
          supabase.from('bookings')
            .select('id, seats_booked, total_price, status, created_at, passenger_id, trip_id, profiles:passenger_id(full_name), trips!inner(origin, destination, driver_id)')
            .eq('trips.driver_id', user.id)
            .order('created_at', { ascending: false })
            .limit(5),
        ]);

        if (!active) return;

        for (const res of [tripsRes, bookingsRes, ratingsRes, recentRes]) {
          if (res.error) throw res.error;
        }

        const weeklyBookings = bookingsRes.data?.length || 0;
        const earnings = (bookingsRes.data || [])
          .filter(b => ['confirmed', 'completed'].includes(b.status))
          .reduce((sum, b) => sum + Number(b.total_price || 0), 0);
        const ratings = ratingsRes.data || [];
        const avgRating = ratings.length ? (ratings.reduce((s, r) => s + r.rating, 0) / ratings.length).toFixed(1) : null;

        setStats({
          activeTrips: tripsRes.count || 0,
          weeklyBookings,
          earnings,
          rating: avgRating,
        });
        setRecentBookings(recentRes.data || []);
      } catch (err) {
        console.error('Dashboard load error:', err);
        if (active) setError('Some data failed to load. Numbers below may be incomplete.');
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => { active = false; };
  }, [user]);

  return (
    <DashboardLayout title="Dashboard">
      <VerificationPopup status={verificationStatus} rejectionReason={driverProfile?.kyc_rejection_reason} />

      <div className="page-header flex-between" style={{ flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1>Welcome back{profile?.full_name ? `, ${profile.full_name.split(' ')[0]}` : ''} 👋</h1>
          <p>Here's what's happening with your trips today.</p>
        </div>
        <TrustBadge level={driverProfile?.trust_level} />
      </div>

      {error && (
        <div className="alert alert-amber" style={{ marginBottom: 20 }}>{error}</div>
      )}

      <div className="dash-layout">
        {/* ── Main column ─────────────────────────────────────────── */}
        <div className="dash-main">
          <div className="grid-4">
            {loading ? (
              <>
                <StatCardSkeleton /><StatCardSkeleton /><StatCardSkeleton /><StatCardSkeleton />
              </>
            ) : (
              <>
                <StatCard label="Active trips" value={stats.activeTrips} />
                <StatCard label="Bookings this week" value={stats.weeklyBookings} />
                <StatCard label="Earnings this week" value={formatKES(stats.earnings)} />
                <StatCard label="Rating" value={stats.rating ?? '—'} sub={stats.rating ? `${(driverProfile?.trips_completed || 0)} trips completed` : 'No ratings yet'} />
              </>
            )}
          </div>

          <div className="card card-pad">
            <div className="flex-between" style={{ marginBottom: 16 }}>
              <h3 style={{ fontSize: 16 }}>Recent bookings</h3>
              <Link to="/driver/bookings" className="btn btn-sm btn-ghost">View all</Link>
            </div>

            {loading ? (
              <div>
                <BookingRowSkeleton />
                <BookingRowSkeleton />
                <BookingRowSkeleton />
              </div>
            ) : recentBookings.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🎫</div>
                <h3>No bookings yet</h3>
                <p>Once passengers book your trips, they'll show up here.</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {recentBookings.map(b => (
                  <div key={b.id} className="flex-between" style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                    <div>
                      <strong style={{ fontSize: 13.5 }}>{b.profiles?.full_name || 'Passenger'}</strong>
                      <p style={{ margin: '2px 0 0', fontSize: 12.5, color: 'var(--text-muted)' }}>
                        {b.trips?.origin} → {b.trips?.destination} · {b.seats_booked} seat{b.seats_booked > 1 ? 's' : ''}
                      </p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 13.5, fontWeight: 700 }}>{formatKES(b.total_price)}</div>
                      <BookingStatusBadge status={b.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── Right rail ──────────────────────────────────────────── */}
        <div className="dash-rail">
          <div className="card card-pad">
            <h3 style={{ fontSize: 14, marginBottom: 14, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Quick actions
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {QUICK_ACTIONS.map(a => {
                const disabled = a.requiresVerified && !isDriverVerified;
                const isPrimary = a.requiresVerified && !disabled;
                const inner = (
                  <>
                    <span className="quick-action-icon">{a.icon}</span>
                    <div style={{ minWidth: 0 }}>
                      <strong style={{ fontSize: 13.5, display: 'block' }}>{a.title}</strong>
                      <p style={{ margin: '2px 0 0', fontSize: 12, color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {disabled ? 'Requires verification' : a.sub}
                      </p>
                    </div>
                  </>
                );
                const className = `quick-action${isPrimary ? ' quick-action-primary' : ''}${disabled ? ' disabled' : ''}`;
                return disabled ? (
                  <div key={a.to} className={className}>{inner}</div>
                ) : (
                  <Link key={a.to} to={a.to} className={className} style={{ textDecoration: 'none', color: 'inherit' }}>
                    {inner}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

const TRUST_COLORS = {
  1: { color: '#64748B', bg: '#F1F5F9' },
  2: { color: '#0E7490', bg: 'var(--primary-xlight)' },
  3: { color: '#16A34A', bg: 'var(--green-light)' },
  4: { color: '#F59E0B', bg: 'var(--amber-light)' },
  5: { color: '#F97316', bg: 'var(--accent-light)' },
};

function TrustBadge({ level }) {
  const l = level || 1;
  const { color, bg } = TRUST_COLORS[l] || TRUST_COLORS[1];
  return (
    <span
      className="badge"
      style={{ background: bg, color, border: `1px solid ${color}33` }}
    >
      Trust Level {l}
    </span>
  );
}

function StatCard({ label, value, sub }) {
  return (
    <div className="stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  );
}

function StatCardSkeleton() {
  return (
    <div className="skeleton-stat-card">
      <div className="skeleton skeleton-text" style={{ width: '50%' }} />
      <div className="skeleton skeleton-title" style={{ width: '40%' }} />
    </div>
  );
}

function BookingRowSkeleton() {
  return (
    <div className="skeleton-row">
      <div style={{ flex: 1 }}>
        <div className="skeleton skeleton-text" style={{ width: '35%', marginBottom: 8 }} />
        <div className="skeleton skeleton-text" style={{ width: '60%' }} />
      </div>
      <div className="skeleton skeleton-text" style={{ width: 60 }} />
    </div>
  );
}

function BookingStatusBadge({ status }) {
  const map = {
    pending: 'badge-amber', confirmed: 'badge-teal', completed: 'badge-green',
    cancelled: 'badge-danger', no_show: 'badge-danger',
  };
  return <span className={`badge ${map[status] || 'badge-gray'}`}>{status.replace('_', ' ')}</span>;
}