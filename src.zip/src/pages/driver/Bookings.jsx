import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import DashboardLayout from '../../components/shared/DashboardLayout';
import BookingCard from '../../components/shared/BookingCard';

const STATUS_TABS = [
  { key: 'all', label: 'All' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

export default function Bookings() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const tripFilter = searchParams.get('trip');

  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusTab, setStatusTab] = useState('all');
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState('');

  async function load() {
    setLoading(true);
    let query = supabase
      .from('bookings')
      .select('*, profiles:passenger_id(full_name, phone), trips!inner(origin, destination, departure_time, driver_id)')
      .eq('trips.driver_id', user.id)
      .order('created_at', { ascending: false });
    if (tripFilter) query = query.eq('trip_id', tripFilter);

    const { data, error: err } = await query;
    if (!err) setBookings(data || []);
    setLoading(false);
  }

  useEffect(() => { if (user) load(); }, [user, tripFilter]);

  async function markNoShow(bookingId) {
    if (!confirm('Mark this passenger as a no-show? This cannot be undone.')) return;
    setBusyId(bookingId); setError('');
    const { error: err } = await supabase.rpc('mark_no_show', { p_booking_id: bookingId });
    setBusyId(null);
    if (err) setError(err.message); else load();
  }

  const filtered = statusTab === 'all' ? bookings : bookings.filter(b => b.status === statusTab);

  return (
    <DashboardLayout title="Bookings">
      <div className="page-header">
        <h1>Bookings</h1>
        <p>{tripFilter ? "Bookings for this trip." : "All bookings across your trips."}</p>
        {tripFilter && <Link to="/driver/bookings" className="btn btn-sm btn-ghost" style={{ marginTop: 8 }}>Clear trip filter</Link>}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {STATUS_TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setStatusTab(t.key)}
            className={`btn btn-sm ${statusTab === t.key ? 'btn-primary' : 'btn-outline'}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error && <div className="alert alert-danger" style={{ marginBottom: 16 }}>{error}</div>}

      {loading ? (
        <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🎫</div>
          <h3>No bookings here</h3>
          <p>Once passengers book your trips, they'll show up here.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {filtered.map(b => (
            <BookingCard
              key={b.id}
              booking={b}
              personName={b.profiles?.full_name}
              personLabel={b.profiles?.phone || 'Passenger'}
              tripLabel={`${b.trips?.origin} → ${b.trips?.destination} · ${new Date(b.trips?.departure_time).toLocaleDateString('en-KE', { day: 'numeric', month: 'short' })}`}
              actions={
                b.status === 'confirmed' && b.trips?.departure_time && new Date(b.trips.departure_time) <= new Date() ? (
                  <button className="btn btn-sm btn-outline" disabled={busyId === b.id} onClick={() => markNoShow(b.id)}>
                    {busyId === b.id ? <span className="spinner" /> : 'Mark no-show'}
                  </button>
                ) : null
              }
            />
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}